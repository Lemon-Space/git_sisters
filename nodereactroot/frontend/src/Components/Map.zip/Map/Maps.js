
import React from 'react'
import './Maps.css'
import { YMaps, Map, Placemark } from 'react-yandex-maps';


 export default function Maps () {

     return(

       

         <div className="Maps">
           
                <div className="write">
                    <h3 className="write_h3">Напишите нам!</h3>
                    <div className="Write_div">
                        <input placeholder='Ваше имя' className='write_name'></input>
                        <input placeholder='Телефон' className='write_number'></input>
                        <input placeholder='E-Mail *' className='write_mail'></input>
                        <input placeholder='Сообщение' className='write_massage'></input>
                        <button className='write_button'>Отправить</button>
                    </div>
                </div >
                    <YMaps >
                        <div class="smallMap" >
                            Мы находимся тут!
                            <Map id="map" defaultState={{ center: [61.239648, 73.392520], zoom: 14 }} style={{width:'450px' , height:'500px'}}>
                                <Placemark defaultGeometry={[61.239648, 73.392520]} />
                            </Map>
                        </div>
                    </YMaps>
        
                </div>
     )
 }

 