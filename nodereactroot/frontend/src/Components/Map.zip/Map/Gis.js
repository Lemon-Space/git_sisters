import DG from '2gis-maps'
import React, { useEffect } from "react";


 

    const Map = () => {
        useEffect(() =>{
            let map 
            map = DG.map('map-container',{
                center:[55.31,25.23],
                zoom:5
            }) 
            
        }, [])
    



     return(

       

         
                <div className="gis">
                    <div className="map-container"  style={{width:'450px' , height:'500px'}}>

                    </div>
                              
                </div>
     )
    }

    export default Map;